const getData = () => {
  let data = [
    {
      src: `https://source.unsplash.com/random/500x500?sig=${Math.floor(Math.random() * 999)}`,
      height: 500,
      author: 'Awesome'
      
    }, {
      src: `https://source.unsplash.com/random/500x400?sig=${Math.floor(Math.random() * 999)}`,
      height: 500,
      author: 'Awesome'
    }, {
      src: `https://source.unsplash.com/random/500x700?sig=${Math.floor(Math.random() * 999)}`,
      height: 500,
      author: 'Awesome'
    }, {
      src: `https://source.unsplash.com/random/500x250?sig=${Math.floor(Math.random() * 999)}`,
      height: 550,
      author: 'Awesome'
    }, {
      src: `https://source.unsplash.com/random/500x800?sig=${Math.floor(Math.random() * 999)}`,
      height: 800,
      author: 'Awesome'
    }, 
  ]
  const AlbumThatPassed =  data.filter(function(Data){
    return Data.height > 500
  })
  return  AlbumThatPassed;
}

export default getData;