# Dinamic React gallery
This is a Gallery that distributes images depending on a threshold so the columns have roughly the same height. 
